-- Replace this with the final SQL query for Question 2 (even regNo)
SELECT col1, COUNT(*) FROM sales WHERE dt >= '2024-01-01' GROUP BY col1;
