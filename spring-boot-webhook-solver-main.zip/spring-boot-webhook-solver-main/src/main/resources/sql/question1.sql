-- Replace this with the final SQL query for Question 1 (odd regNo)
SELECT * FROM my_table WHERE some_condition;
