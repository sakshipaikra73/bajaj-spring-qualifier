package com.example.webhooksolver;

import com.example.webhooksolver.model.Submission;
import com.example.webhooksolver.repo.SubmissionRepository;
import com.example.webhooksolver.service.WebhookService;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.Instant;
import java.util.Optional;

@SpringBootApplication
public class WebhookSolverApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebhookSolverApplication.class, args);
    }

    /**
     * ApplicationRunner runs once on startup — no controller needed.
     */
    @Bean
    ApplicationRunner runner(WebhookService webhookService, SubmissionRepository submissionRepository) {
        return new ApplicationRunner() {
            @Override
            public void run(ApplicationArguments args) throws Exception {
                // Step 1: Generate webhook and receive response
                var resp = webhookService.generateWebhook();

                // resp should contain "webhook" (URL) and "accessToken"
                String webhookUrl = resp.getWebhookUrl();
                String accessToken = resp.getAccessToken();

                // Step 2: decide question based on regNo parity
                String regNo = webhookService.getRegNo();
                int lastTwo = webhookService.getLastTwoDigits(regNo);
                boolean isOdd = (lastTwo % 2) == 1;

                // Load the final SQL from resources (question1.sql or question2.sql)
                String finalQuery = webhookService.loadFinalQuery(isOdd ? 1 : 2);

                // Persist locally
                Submission submission = new Submission();
                submission.setRegNo(regNo);
                submission.setFinalQuery(finalQuery);
                submission.setSubmittedAt(Instant.now());
                submissionRepository.save(submission);

                // Step 3: POST finalQuery to webhook using accessToken as Authorization header
                webhookService.submitFinalQuery(webhookUrl, accessToken, finalQuery);

                System.out.println("Startup flow completed. Final query sent and stored.");
            }
        };
    }
}
